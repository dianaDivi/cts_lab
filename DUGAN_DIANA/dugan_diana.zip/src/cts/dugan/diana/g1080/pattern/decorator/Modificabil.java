package cts.dugan.diana.g1080.pattern.decorator;

public interface Modificabil {
	public void modificaReclama(int durata, int moment);

}
