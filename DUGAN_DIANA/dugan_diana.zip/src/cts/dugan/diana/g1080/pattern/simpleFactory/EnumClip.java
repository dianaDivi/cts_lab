package cts.dugan.diana.g1080.pattern.simpleFactory;

public enum EnumClip {
	VIDEO,TUTORIAL
}
